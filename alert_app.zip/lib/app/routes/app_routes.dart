part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const REGISTRATION = _Paths.REGISTRATION;
  static const PROFIL = _Paths.PROFIL;
  static const ALERT = _Paths.ALERT;
  static const FULLSCREEN = _Paths.FULLSCREEN;
}

abstract class _Paths {
  _Paths._();
  static const REGISTRATION = '/registration';
  static const PROFIL = '/profil';
  static const ALERT = '/alert';
  static const FULLSCREEN = '/fullscreen';
}
