class StatusResponse {
  static const SUCCESS = 200;
  static const SUCCESS_201 = 201;
  static const FAIL = 400;
}
